package PA2;

/*
 * Fall 2019
 * Ryan Hoang
 * Programming Assignment 2
 * CS555
 */

public final class Triple
{
    public Object first;
    public Object second;
    public Object third;

    public Triple(Object a, Object b, Object c)
    {
        this.first = a;
        this.second = b;
        this.third = c;
    }
}
