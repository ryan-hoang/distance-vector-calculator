My program can be run with the following on the command line:

java -jar DistanceVectorCalculator-1.0.jar

Ensure the network.txt file is in the same directory as the jar file.

To build my program, you must use Apache Maven 3.6.0
To do so ensure you are inside the DistanceVectorCalculator directory and run "mvn clean install".
The compiled .jar file will be output in the target directory.

Source files for the assignment are located in: "DistanceVectorCalculator/src/main/java/PA2/"